/**
 * @userProfileServices contains services releted to user routes
 * @auth contain authentication logics needed to secure the routes
 */
const router                =   require('express').Router();
const userProfileServices   =   require('../../../services/api_services/user_profile_services');
const auth                  =   require('../../../services/check_auth_service/is_authenticated_service');
const contractServices      =   require('../../../services/api_services/contract_services');
const adminServices   =   require('../../../services/api_services/admin_services');
/**
 ** Router for user related functionalities
 */
router.post('/email', userProfileServices.checkemailService);
router.post('/mobile', userProfileServices.checkmobileService)
router.post('/register', userProfileServices.registerService);
router.get('/verifyemail/:activationtoken',  userProfileServices.varifyEmail);
router.post('/login',  userProfileServices.loginService);
router.post('/forgetpassword', userProfileServices.forgetPassword);
router.get('/generatepassword/:activationtoken',  userProfileServices.varifyPassword);
router.post('/changepassword/:activationtoken',  userProfileServices.changePassword);

router.post('/resetpassword', userProfileServices.resetPassword);
router.get('/logout',  auth.isAuth, userProfileServices.logout);
router.get('/profile',  auth.isAuth, userProfileServices.myProfile);
router.get('/resendemail',  auth.isAuth, userProfileServices.resendEmailVerification);
router.post('/passwordchange', auth.isAuth, userProfileServices.profilePassswordChange);
router.post('/paypalemail', auth.isAuth, userProfileServices.addPaypalEmail);
router.post('/profilepicture', auth.isAuth, userProfileServices.editProfilePicture);


/**
 ** Router for contracts
 */
router.post('/contract', auth.isAuth, contractServices.createContract); //done
router.post('/buyers', auth.isAuth, contractServices.buyerList); //done
router.get('/contract/:sContaractId', auth.isAuth, contractServices.viewContract);//done
router.post('/buyersign', auth.isAuth, contractServices.addBuyerSignature);
router.post('/contractdespute', auth.isAuth, contractServices.contractDespute);
router.post('/contractaccept', auth.isAuth, contractServices.contractAccept);
router.post('/contracts', auth.isAuth, contractServices.contractList);
router.get('/contractstatus', auth.isAuth, contractServices.getContractStatus);


/**
 ** Admin Router 
 */
router.post('/adminlogin',  adminServices.loginService);
router.get('/adminprofile',  auth.isAuth, adminServices.myProfile);
router.post('/admineditprofile',  auth.isAuth, adminServices.editProfile);
router.post('/adminapprovallist', auth.isAuth, adminServices.getPendingApprovalUserList);
router.get('/adminuserprofile/:sUserId',  auth.isAuth, adminServices.userProfile);
router.post('/adminuserapprove',  auth.isAuth, adminServices.userApproved);
router.post('/adminusers', auth.isAuth, adminServices.getApprovedUserList);
router.post('/admincmspages', auth.isAuth, adminServices.getCMSList);
router.post('/adminaddcms', auth.isAuth, adminServices.addNewCMS);
router.post('/admineditcms', auth.isAuth, adminServices.editCMS);
router.get('/admindashboard', auth.isAuth, adminServices.getDashboardData);
router.post('/adminremoveuser', auth.isAuth, adminServices.removeUser);



module.exports = router;