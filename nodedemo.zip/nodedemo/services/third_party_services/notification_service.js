/**
 * Developer: Mr.Node
 * Notification is service to Check Users's Notification settings and send Pusn, email and Message notification accordingly 
 */
const _ = require('lodash')
const debug = require('debug')('http')
const usersModel = require('../../models/users_models')
const userNotificationModel = require('../../models/users_notificationsettings_models')
const fcmpush = require('./firebase_service')
//const emailService = require('./email_service')
const ObjectId = require('mongodb').ObjectID

/**
 * 
 * @param {*} sUserId 
 * @param {*} sSettingName 
 * @param {*} data 
 * @param {*} mailData 
 */

const sendNotification = function (sUserId, sSettingName, data, mailData) {

    if(sSettingName =='reportpost' || sSettingName =='reportlocation' || sSettingName =='feature') {
      debug('send push by admin'); 
      /** Get User's Data to send notification  */
      usersModel.aggregate([
        {
          $match: {
            '_id': ObjectId(sUserId)
          }
        }, {
          $project: {
            '_id': 1,
            'sEmail': 1,
            'sMobile': 1,
            'aJwtTokens': '$aJwtTokens.sPushToken'
          }
        }
      ]).exec(function (err, userData) {

        let user = userData[0]
        /** Send Push notification */
        if (!_.isEmpty(user.aJwtTokens)) {
          title =  mailData.subject
          fcmpush.sendPushMessage(user.aJwtTokens, {
            body: title,
            sound: 'default'
          }, data).then((err, res) => {
            console.log('error ' + err)
            console.log('res' + res)
          });
        }  
      });  
    } else {
      /** Check which notitication is on for user */
      // eslint-disable-next-line handle-callback-err
      userNotificationModel.find({ 'sUserId': sUserId, 'sNotificationType': sSettingName, 'eStatus': 'y' }, (err, settingsData) => {
        debug('settingsData')
        //debug(settingsData)
        if (!_.isNull(settingsData)) {
        /** Get User's Data to send notification  */
          usersModel.aggregate([
            {
              $match: {
                '_id': ObjectId(sUserId)
              }
            }, {
              $project: {
                '_id': 1,
                'sEmail': 1,
                'sMobile': 1,
                'aJwtTokens': '$aJwtTokens.sPushToken'
              }
            }
          ]).exec(function (err, userData) {
            if (err) return next(err)
            //debug('userData')
            //debug(userData)
            let user = userData[0]
            settingsData.forEach((value) => {
            /** Send Push notification */
              if (value.sType == 'push' && !_.isEmpty(user.aJwtTokens)) {
              // debug('send push')
                title =  mailData.subject
                fcmpush.sendPushMessage(user.aJwtTokens, {
                  body: title,
                  sound: 'default'
                }, data).then((err, res) => {
                  console.log('error ' + err)
                  console.log('res' + res)
                })
              }
            }, this)
          })
        }
      })
    }
}

module.exports = {
  sendNotification
}
