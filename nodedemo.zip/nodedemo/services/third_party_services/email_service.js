/**
 * Developer: Mr.Node
 * email service is used to send email 
 */

const nodemailer = require('nodemailer')
const fs = require('fs')
const ejs = require('ejs')
const debug = require('debug')('http')

/**
 * @name Send Mail
 * @param {*} templateName : Name of template to load 
 * @param {*} data : Data to be replaced in template
 * @param {*} mailOption : subject and to 
 */
const sendEmail = function (templateName, data, mailOption) {
  debug(templateName, data, mailOption)
  let template = fs.readFileSync(constants.emailTemplatePath + templateName, {
    encoding: 'utf-8'
  })

  let emailBody = ejs.render(template, data)

  // let mailOption = mailOption;

  mailOption.html = emailBody

  let transporter = nodemailer.createTransport(constants.nodeMailerTransporter)
  let nodeMailerOptions = mailOption
  return transporter.sendMail(nodeMailerOptions).then(function (success) {
    debug('sendEmail success')
    debug(success)
  }).catch(function (err) {
    debug('sendEmail err')
    debug(err)
    if (err) return next(err)
    // return err;
  })
}

module.exports = {
  sendEmail
}
