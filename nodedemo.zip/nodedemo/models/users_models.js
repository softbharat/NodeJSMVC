/*
 * User model schema
 */
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const validator = require('node-mongoose-validator');
const Schema = mongoose.Schema;
const constants = require('./../costants');
const messages = require('./../messages/messages');
const bcrypt = require('bcrypt-nodejs');
const utility = require('./../config/utility');
const nodemailer = require('nodemailer');

const Users = new Schema({
    sFirstName: {
        type: String
    },
    sLastName: {
        type: String
    },
    sFullName: {
        type: String
    },
    sEmail: {
        type: String
    },
    sPassword: {
        type: String
    },
    sCountryCode: {
        type: String
    },
    sMobile: {
        type: String
    },
    eStatus: {
        type: String,
        enum: ['y', 'n', 'd'],
        default: 'y'
    },
    sAdminApproved: {
        type: String,
        enum: ['a', 'r', 'p'], //a=accept, r=reject, p=pending
        default: 'p'
    },
    sUserType: {
        type: Number,
        enum: [0,1], //0=Normal user , 1= Admin 
        default: 0
    },
    sProfileImage: {
        type: String
    },
    sIdentityProof: { //not used 
        type: String
    },
    dCreatedDate: {
        type: Date,
        default: Date.now
    },
    dUpdatedDate: {
        type: Date
    },
    aJwtTokens: [{
        sDeviceAuth: String,
        sPushToken: String,
        sDeviceType: {
            type: String,
            enum: ['IOS', 'Android'],
            default: 'IOS'
        },
        dLoginTimeStamp: {
            type: Date,
            default: Date.now
        },
        sIpAddress: String
    }],
    sActivationToken: {
        type: String
    },
    sForgetPasswordActivationToken: {
        type: String
    },
    sMobileVerified: {
        type: Number,
        enum: [0, 1],
        default: 0
    },
    sEmailVerified: {
        type: Number,
        enum: [0, 1],
        default: 0
    },
    sPayPalEmail:{
        type:String
    },
    sProfilePicture :{
        type:String
    },
    sPayPalBusinessAcount:{
        type:String
    }
});


//Users.index( { "sUsername": 1 }, { unique: true } )
Users.pre('save', function(next) {
    var user = this;
    next();
});


Users.methods.generateAuthToken = function(req) {
    
    var user = this;
    var obj = {
        sIpAddress: req.connection.remoteAddress,
        dLoginTimeStamp: utility.nowDate(),       
        sDeviceAuth: jwt.sign({
            _id: (user._id).toHexString()
        }, constants.jwtPassphere)
    };
    user.aJwtTokens.push(obj);
    return user.save().then(function() {
        return obj.sDeviceAuth;
    }).catch((err) => {
        console.log(err);
    });
};

Users.statics.findByToken = function(token) {
    var User = this;
    var decoded;
    try {
        decoded = jwt.verify(token, constants.jwtPassphere);
    } catch (e) {
        return new Promise((resolve, reject) => {
            reject();
        });
    }

    var query = {
        '_id': decoded._id,
        'aJwtTokens.sDeviceAuth': token
    };
    return User.findOne(query, {
        sMobile: true,
        sProfilePicture: true,
        eStatus: true
    });
};

Users.methods.sendEmail = function(mailOption) {
    var transporter = nodemailer.createTransport(constants.nodeMailerTransporter);
    var nodeMailerOptions = mailOption;
    return transporter.sendMail(nodeMailerOptions).then(function(success) {
       // return success.messageId;
    }).catch(function(err) {
        //return err;
    });
};

module.exports = mongoose.model('users', Users);