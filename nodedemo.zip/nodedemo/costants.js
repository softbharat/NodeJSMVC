/**
 * All the credentials are stored here that needs to be secure..
 */
var ENVIRONMENT='Dev';
const path = require('path');

if(ENVIRONMENT=='Dev')
{
    BASE_URL='http://192.168.11.52:8080/';
    MONGODB_URL='mongodb://192.168.11.52:27017/nodedemo';
}else{
    BASE_URL='http://00.000.00.00:8080/';
    MONGODB_URL='mongodb://000.0.0.0:27017/nodedemo';
}

SITE_URL=BASE_URL+'api/v1/';
constants = {
    apiUrl:SITE_URL,
    dbUrl: MONGODB_URL,
    jwtPassphere: 'sn@djkiHjd',
    nodeMailerTransporter: {
        service: 'Gmail',
        auth: {
            user: 'app@gmail.com', // SMTP email
            pass: '' // Your password
        }
    },  
    uploadPath: './public/uploads',
    avatarUploadPath: './public/uploads/user_avtar',
    proofUploadPath: './public/uploads/proof_media',
    emailTemplatePath: path.join(__dirname, '/public/email_template/'),
    viewTemplatePath: path.join(__dirname, '/public/view/'),
    siteImage: SITE_URL+'public/assets/images/',
    siteName: 'NodeDemo',
    awsAccesskeyID:'',
    awsSecretAccessKey:'',
    awsS3Bucket : '',
    awsS3BucketUrl:'https://demo.s3.amazonaws.com/',
    siteMediaUploadPath:'local', //s3,local
    fireBaseServerKey: '',
    facebookAppID: '',
    facebookAppSecret: '',
    facebookGraphAPIVersion: 'v3.0',
    deepLinkUrl: BASE_URL + 'deeplink?url=',
    fireBaseWebAPIKey:''
};

module.exports = constants;


/*
Success - 200
Already exist - 409
something wrong - 405
Not found /disabled/inactive/deleted- 404
Unauthorised/login failed - 401
Save failed/ error on server - 500
Input data Validation error - 400 
Expectation Failed  / update etc - 417
*/