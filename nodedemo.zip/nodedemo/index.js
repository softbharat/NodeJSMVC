/**
 * Entrypoint of the Demo
 * @app is a middleware require to configure and provide routing
 * @config contains all the configuration environment
 * @apiRoutes contains all the general controller like login registration and filling personal information
 * Node Version: v8.1.4
 * NPM Version: V5.0.3
 * Mongo Version: v3.4.10
 */
const compression = require('compression')
const express = require('express')
const app = express()
app.use(compression())
const config = require('./config')(app)
const validator = require('express-validator')
app.use(validator())
const path = require('path')
//process.env.TZ = 'Asia/Kolkata'
app.use(express.static(path.join(__dirname, '/public')))
app.use('/public', express.static((path.join(__dirname, '/public'))))

const apiRoutes = require('./routes/api/v1/general_routes')

app.use('/api/v1/', apiRoutes)
app.use(function (err, req, res, next) {
  if (!err.statusCode) err.statusCode = 500
  if (!err.aErrors) err.aErrors = ''

  res.status(err.statusCode).jsonp({
    'error': (err.error) ? err.error : err,
    'aErrors': err.aErrors
  })
})