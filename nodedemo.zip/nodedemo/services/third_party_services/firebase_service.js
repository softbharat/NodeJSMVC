/**
 * Developer: Mr.Node
 * Firebase service is used to send push notification 
 */
//http://www.digitstory.com/downstream-messaging-using-fcm-node/
const FCM = require('fcm-node')
const fcm = new FCM(constants.fireBaseServerKey)
const debug = require('debug')('http')

/*
 * name: Send Push Notification
 * 
fcmpush.sendPushMessage('askdjhajkd', {
  title: 'Title of your push notification',
  body: 'Body of your push notification'
}, {
  my_key: 'my value',
  my_another_key: 'my another value'
}).then((err, res) => {
  console.log('error ' + err)
  console.log('rsa' + res)
})
*/
const sendPushMessage = function (tokens, notification, payloadData) {
  //debug('Payload');
  let message = { // this may vary according to the message type (single recipient, multicast, topic, et cetera)
    registration_ids: tokens, // 'registration_ids' for Multiple device token, 'to' for single device token 
    // collapse_key: 'your_collapse_key',
    notification: notification,
    data: payloadData
  }
  //debug(message)
  return new Promise(function (resolve, reject) {
    fcm.send(message, function (err, response) {
      if (err) {
        debug('Error firebase send push')
        debug(err)
      } else {
        debug('Success firebase send push')
        debug(response)
        resolve(response)
      }
    })
  })
}

module.exports = {
  sendPushMessage
}
