const _ = require('lodash');
const async         = require('async');
const constants     = require('../../costants');
const messages      = require('../../messages/messages');
const utility       = require('../../config/utility');
const debug         = require('debug')('http')
const ObjectId      = require('mongodb').ObjectId;
const usersModel    = require('../../models/users_models'); 

const multer    = require('multer');
const mime      = require('mime');
const multerS3  = require('multer-s3');
const AWS       = require('aws-sdk');
const fs        = require('fs');
const md5       = require('md5');
const bcrypt    = require('bcryptjs');
const randomString  = require('random-string');
const ejs           = require('ejs');

var mediaUploadPath = constants.siteMediaUploadPath;


/* S3 BUCKET CONFIGURATION */
AWS.config.update({ accessKeyId: constants.awsAccesskeyID, secretAccessKey: constants.awsSecretAccessKey });

var s3 = new AWS.S3();
if(mediaUploadPath == 's3') {
    // User Profile image upload on live domain - s3 Bucket
    var storage = multerS3({
      s3: s3,
      bucket: constants.awsS3Bucket+'/proof_media',
      acl: 'public-read',
      key: function(req, file, callback) {
        var fileName = md5(file.fieldname + req._id + Date.now());
        callback(null, fileName + '.' + mime.extension(file.mimetype));
      }
    });
} else {
    // User Profile image upload on local domain
    var storage = multer.diskStorage({
        destination: function(req, file, callback) {
            callback(null, constants.proofUploadPath);
        },
        filename: function(req, file, callback) {
            var fileName = md5(file.fieldname + req._id + Date.now());
            callback(null, fileName + '.' + mime.extension(file.mimetype));
        }
    });
}

var uploadProof = multer({
    storage: storage
  }).fields([{
    name: 'sProfileImage',
    maxCount: 1
  }, {
    name: 'sIdentityProof',
    maxCount: 1
  }]);

if(mediaUploadPath == 's3') {
    // User Profile image upload on live domain - s3 Bucket
    var storage = multerS3({
      s3: s3,
      bucket: constants.awsS3Bucket+'/user_avtar',
      acl: 'public-read',
      key: function(req, file, callback) {
        var fileName = md5(file.fieldname + req._id + Date.now());
        callback(null, fileName + '.' + mime.extension(file.mimetype));
      }
    });
} else {
    // User Profile image upload on local domain
    var storage = multer.diskStorage({
        destination: function(req, file, callback) {
            callback(null, constants.avatarUploadPath);
        },
        filename: function(req, file, callback) {
            var fileName = md5(file.fieldname + req._id + Date.now());
            callback(null, fileName + '.' + mime.extension(file.mimetype));
        }
    });
}

var uploadProfile = multer({
    storage: storage
  }).fields([{
    name: 'sProfilePicture',
    maxCount: 1
  }]);



/**
 ** Check user email id is already exist or not 
 */
const checkemailService = (req, res, next) => {
    req.checkBody({
        'sEmail': {
            notEmpty: true,
            isEmail: {
                errorMessage: messages.err_invalid_email
            },
            errorMessage: messages.err_req_email
        }
    });
    req.getValidationResult().then(function(result) {
        var errors = result.useFirstErrorOnly().mapped();
        if (result.array().length > 0) {
            if(!_.isUndefined(errors.sEmail)){
                err = { error:errors.sEmail.msg, statusCode: 400 }
                return next(err)
            }
        } else {
            var body = _.pick(req.body, ['sEmail']);
            usersModel.findOne({
                sEmail: body.sEmail,
                eStatus:'y'
            }, {
                _id: 1
            }, (err, user) => {
                if (err) return next(err);
                if (user === null)
                    return res.status(200).jsonp({
                        'message': messages.success
                    });
                else
                err = { error: messages.email_already_exists, statusCode: 409 }
                return next(err)
            });
        }
    });
};

/**Check mobile no is already exist or not
 * check mobile no with country code 
 */
const checkmobileService = (req, res, next) => {
    req.checkBody({
        'sMobile': {
            notEmpty: true,
            errorMessage: messages.err_req_mobile_required
        },
        'sCountryCode': {
            notEmpty: true,
            errorMessage: messages.err_req_countrycode
        }
        
    });
    req.getValidationResult().then(function(result) {
        var errors = result.useFirstErrorOnly().mapped();
        if (result.array().length > 0) {
            if(!_.isUndefined(errors.sMobile)){
                err = { error:errors.sMobile.msg, statusCode: 400 }
                return next(err)
            } else if(!_.isUndefined(errors.sCountryCode)){
                err = { error:errors.sCountryCode.msg, statusCode: 400 }
                return next(err)
            }
        } else {
            var body = _.pick(req.body, ['sMobile','sCountryCode']);
            usersModel.findOne({
                sMobile: body.sMobile,
                sCountryCode: body.sCountryCode,
                eStatus:'y'
            }, {
                _id: 1
            }, (err, user) => {
                if (err) return next(err);
                if (user === null)
                    return res.status(200).jsonp({
                        'message': messages.success
                    });
                else
               
                err = { error: messages.mobile_already_exists, statusCode: 409 }
                return next(err)
            });
        }
    });
};

/**
 * Register a new user
 */
const registerService = (req, res, next) =>{
    console.log('register api call');

    uploadProof(req, res, function(err) {
        let body = _.pick(req.body, ['sFirstName', 'sLastName', 'sCountryCode','sMobile', 'sEmail', 'sPassword','sMobileVerified', 'sConfirmPassword']);
        
        if(_.isEmpty(body.sFirstName)) {
            err = { error: messages.err_req_fname, statusCode:400}
            return next(err);
        }

        if(_.isEmpty(body.sLastName)) {
            err = { error: messages.err_req_lname, statusCode:400}
            return next(err);
        }

        if(_.isEmpty(body.sEmail)) {
            err = { error: messages.err_req_email, statusCode:400}
            return next(err);
        }
        if(_.isEmpty(body.sPassword)) {
            err = { error: messages.err_req_password, statusCode:400}
            return next(err);
        }
        if(_.isEmpty(body.sConfirmPassword)) {
            err = { error: messages.err_repassword, statusCode:400}
            return next(err);
        }
        if(body.sPassword != body.sConfirmPassword) {
            err = { error: messages.password_not_matched, statusCode:400}
            return next(err);
        }
        
        var query = { 'sEmail': body.sEmail, eStatus:'y' }
       
        usersModel.findOne(query, (error, user) => {
            if (error) {
                err = { error: error }
                return next(err)
            }
            if (user) {
                err = { error: messages.email_already_exists, statusCode: 409 }
                return next(err)
            }

            var sProfileImage = '';
            var sIdentityProof = '';
            if (!_.isEmpty(req.files)) {
                var myFileObject = req.files;
                //AMazon S3 Bucket Path :'https://snipture.s3.amazonaws.com/user_avtar/b9b9cc890a0dcabfb0bf3859c25a20d6.jpeg'
                var sProfileImageObj = myFileObject.sProfileImage;
                if (!_.isUndefined(sProfileImageObj)) {
                    //Get Image Name based on uploaded path
                    if(mediaUploadPath == 's3') {
                        imgname = sProfileImageObj[0].key;
                    } else {
                        imgname = sProfileImageObj[0].filename;
                    } 
                    sProfileImage = 'proof_media/'+imgname;
                }
                
                var sIdentityProofObj = myFileObject.sIdentityProof;
                if (!_.isUndefined(sIdentityProofObj)) {
                    //Get Image Name based on uploaded path
                    if(mediaUploadPath == 's3') {
                        imgname = sIdentityProofObj[0].key;
                    } else {
                        imgname = sIdentityProofObj[0].filename;
                    }
                    sIdentityProof = 'proof_media/'+imgname;
                }
            }
            var salt = bcrypt.genSaltSync(10);
            var hash = bcrypt.hashSync(req.body.sPassword, salt);
            body.sPassword = hash;

            body = _.extend(body, {
                sIdentityProof:sIdentityProof,
                sProfileImage:sProfileImage,
                dCreatedDate: utility.nowDate(),
                dUpdatedDate: utility.nowDate()
            });
            var newuser = new usersModel(body);
            newuser.save().then((lastAddedUser) => {

                //send email for user verification 
                var newUser = new usersModel();
                var sActivationToken = md5(randomString({
                    length: 6,
                    letters: true
                }));
                usersModel.update({
                    _id: lastAddedUser._id
                }, {
                    $set: {
                        sActivationToken: sActivationToken
                    }
                }).then((success) => {
                    var template = fs.readFileSync(constants.emailTemplatePath + 'account_activation.html', {
                        encoding: 'utf-8'
                    });
                    var ACTIVELINK = SITE_URL + 'verifyemail/' + sActivationToken

                    var emailBody = ejs.render(template, {
                        sUsername:lastAddedUser.sFirstName,
                        SITE_IMAGE: constants.siteImage,
                        SITE_NAME: constants.siteName,
                        ACTIVELINK: ACTIVELINK
                    });
                    var mailOption = {
                        to: lastAddedUser.sEmail, // list of receivers
                        subject: "Account Activation", // Subject line
                        html: emailBody
                    }
                    newUser.sendEmail(mailOption).then(function(success) {
                        //just generate token 
                        lastAddedUser.generateAuthToken(req).then((token) => {
                            return res.header({
                                'Authorization': token
                            }).jsonp({
                                'message': messages.success,
                                'Authorization': token
                            });
                        }).catch((error) => {
                            err = { error: messages.login_failed, statusCode: 401 }
                            return next(err)
                        });
                    }).catch(function(err) {
                        err = { error: messages.something_wentwrong, statusCode: 405 }
                        return next(err)
                    });
                });
            
            });

        });
    });    
}


/** Display web page for Change the password
 ** If user already changed password then display activated web page content
 ** If user is not changed password then display change password page content
 */
const varifyEmail = (req, res, next) => {
    var query = {
        sActivationToken: req.params.activationtoken
    };
    usersModel.findOne(query, {
        _id: 1,
        sUsername: 1,
        sEmail: 1,
    }, (error, data) => {
        if (data == null) {
            var template = fs.readFileSync(constants.viewTemplatePath + 'account_activated.html', {
                encoding: 'utf-8'
            });
            res.send(template);
        } else {
            usersModel.update(
                {_id: ObjectId(data._id)},
                {
                    $set:{
                        sEmailVerified :1,
                        sActivationToken:''
                    }
                }
            ).then((success)=>{
                var template = fs.readFileSync(constants.viewTemplatePath + 'account_activation.html', {
                    encoding: 'utf-8'
                });
                res.send(template);
            });
           
        }
    });
};


/**
 ** Login a User with email/username & password 
 ** Remove all device token before login 
 */
const loginService = (req, res, next) => {
    debug('login api call');
    var body = _.pick(req.body, ['sEmail', 'sPassword']);
    if (_.isEmpty(body.sEmail)) {
        err = { error: messages.err_req_email, statusCode: 400 }
        return next(err)
    }
    if (_.isEmpty(body.sPassword)) {
        err = { error: messages.err_req_password, statusCode: 400 }
        return next(err)
    }

    var query = { 'sEmail': body.sEmail, 'sMobileVerified':1 }
    
    usersModel.findOne(query, (error, user) => {
        if (error) {
            err = { error: error }
            return next(err)
        }
        if (!user) {
            err = { error: messages.invalid_credentials, statusCode: 404 }
            return next(err)
        }

        if (user.eStatus === 'n'){
            err = { error: messages.not_varified, statusCode: 404 }
            return next(err)
        }
       
        if (bcrypt.compareSync(body.sPassword, user.sPassword)) {
            //Remove All token from login users
            usersModel.update(
                {_id: ObjectId(user._id)},
                {$set : {'aJwtTokens': [] }},
                {multi:true}
            ).then((success) => {
                return generateAndSendAuthToken(user,req,res);
            });
        } else {
            err = { error: messages.invalid_credentials, statusCode: 404 }
            return next(err)
        }
    });
};

/**
 ** Generate auth taken when user login or signup 
 */
function generateAndSendAuthToken(user,req,res) {
    user.generateAuthToken(req).then((token) => {
        return res.header({
            'Authorization': token
        }).jsonp({
            'message': messages.success_login,
            'Authorization': token
        });

    }).catch((error) => {
        err = { error: messages.login_failed, statusCode: 401 }
        return next(err)
    });
}


/**
 * Forget Password
 */
const forgetPassword = (req, res, next) =>{
    let body = _.pick(req.body, ['sEmail']);

    if(_.isEmpty(body.sEmail)) {
        err = { error: messages.err_req_email, statusCode: 400 }
        return next(err)
    }

    usersModel.findOne({'sEmail': body.sEmail}, {_id:1, sEmail:1}, (err,user) =>{
        if(err) return next(err);
        if(_.isEmpty(user)) {
            err = { error: messages.user_not_found, statusCode: 404 }
            return next(err)
        }
        if (user.eStatus === 'n'){
            err = { error: messages.user_inactive, statusCode: 404 }
            return next(err)
        }

        var newUser = new usersModel();
        var sForgetPasswordActivationToken = md5(randomString({
            length: 6,
            letters: true
        }));
        usersModel.update({
            _id: user._id
        }, {
            $set: {
                sForgetPasswordActivationToken: sForgetPasswordActivationToken
            }
        }).then((success) => {
            var template = fs.readFileSync(constants.emailTemplatePath + 'forgotpassword.html', {
                encoding: 'utf-8'
            });
            var ACTIVELINK = constants.apiUrl + 'generatepassword/' + sForgetPasswordActivationToken

            var emailBody = ejs.render(template, {
                sUsername: user.sFirstName,
                SITE_IMAGE: constants.siteImage,
                SITE_NAME: constants.siteName,
                ACTIVELINK: ACTIVELINK
            });
            var mailOption = {
                to: user.sEmail, // list of receivers
                subject: "Password Reset Request", // Subject line
                html: emailBody
            }
            newUser.sendEmail(mailOption).then(function(success) {
                return res.status(200).jsonp({
                    "message": messages.succ_resetpasswordlink
                });
            }).catch(function(err) {
                err = { error: messages.something_wentwrong, statusCode: 405 }
                return next(err)
            });
        });
    });
}

/** Display web page for Change the password
 ** If user already changed password then display activated web page content
 ** If user is not changed password then display change password page content
 */
const varifyPassword = (req, res, next) => {
    var query = {
        sForgetPasswordActivationToken: req.params.activationtoken
    };
    usersModel.findOne(query, {
        _id: 1,
        sUsername: 1,
        sEmail: 1,
    }, (error, data) => {
        if (data == null) {
            var template = fs.readFileSync(constants.viewTemplatePath + 'account_password_verified.html', {
                encoding: 'utf-8'
            });
            res.send(template);
        } else {
            var template = fs.readFileSync(constants.viewTemplatePath + 'changepassword.html', {
                encoding: 'utf-8'
            });
            var Body = ejs.render(template, {
                activationtoken: req.params.activationtoken,
                SITE_IMAGE: constants.siteImage,
                SITE_URL: constants.apiUrl,
            });
            res.send(Body);
        }
    });
};

/** Update password from web page when click on submit button 
 ** If user already changed password then display activated web page content
 ** Update password in local domain as well as quick blox panel
 ** after success display reset password web page content 
 */
const changePassword = (req, res, next) => {
    var query = {
        sForgetPasswordActivationToken: req.params.activationtoken
    };
    var errors = null;
    usersModel.findOne(query, {
        _id: 1,
        sUsername: 1,
        sEmail: 1,
    }, (error, data) => {
        if (error) {
            err = { error: error }
            return next(err)
        }
        if (data == null) {
            var template = fs.readFileSync(constants.viewTemplatePath + 'account_password_verified.html', {
                encoding: 'utf-8'
            });
            res.send(template);
        } else {
            req.checkBody({
                'newPassword': {
                    notEmpty: true,
                    errorMessage: messages.err_req_newpassword
                },
                'confirmPassword': {
                    notEmpty: true,
                    errorMessage: messages.err_repassword
                },
            });

            req.getValidationResult().then(function(result) {
                var errors = result.useFirstErrorOnly().mapped();
        
                if (result.array().length > 0) {
                } else {
                    
                    var body = _.pick(req.body, ['newPassword', 'confirmPassword']);
                    //var sCurrentPassword = body.sCurrentPassword;
                    var sNewPassword = body.newPassword;
                    var sRePassword = body.confirmPassword;
                    var query = {
                        _id: data._id
                    };
        
                    usersModel.findOne(query, {
                        _id: 1,
                        sUserName: 1,
                        sEmail: 1,
                        sPassword: 1
                    }, (error, user) => {
                        if (error) {
                            err = { error: error }
                            return next(err)
                        }
                        var salt = bcrypt.genSaltSync(10);
                        var hash = bcrypt.hashSync(sNewPassword, salt);
    
                        var updateQry = {
                            sPassword: hash,
                            sForgetPasswordActivationToken:''
                        };
                        utility.removenull(updateQry);
                        usersModel.update(query, {
                            $set: updateQry
                        }).then((success) => {
                            
                            var template = fs.readFileSync(constants.viewTemplatePath + 'reset_password.html', {
                                encoding: 'utf-8'
                            });
                            res.send(template);
                            
                        }).catch((error) => {
                            err = { error: messages.changed_password_failed, statusCode: 417 }
                            return next(err)
                        });
                    });
                }
            });
        }    
    });     
};



/**
 ** Password reset before login  
 */
const resetPassword = (req, res, next) =>{
    let body =  _.pick(req.body, ['sNewPassword', 'sConfirmPassword', 'sUserId']);

    if(_.isEmpty(body.sNewPassword)) {
        err = { error: messages.err_req_new_password, statusCode:400}
        return next(err);
    }

    if(_.isEmpty(body.sConfirmPassword)) {
        err = { error: messages.err_repassword, statusCode:400}
        return next(err);
    }
    if(_.isEmpty(body.sUserId)) {
        err = { error: messages.err_req_userid, statusCode:400}
        return next(err);
    }

    if(body.sNewPassword != body.sConfirmPassword) {
        err = { error: messages.password_not_matched, statusCode:400}
        return next(err);
    } else {
       
        var query = {
            _id: ObjectId(body.sUserId)
        };
        usersModel.findOne(query,(err, result)=>{
            if(err) return next(err);
            if(_.isEmpty(result)) {
                err = { error: messages.user_not_found, statusCode: 404 }
                return next(err)
            } else {
                var salt = bcrypt.genSaltSync(10);
                var hash = bcrypt.hashSync(body.sNewPassword, salt);

                var updateQry = {
                    sPassword: hash,
                };
                utility.removenull(updateQry);
                usersModel.update(query, {
                    $set: updateQry
                }).then((success) => {
                    return res.status(200).jsonp({
                        'message':messages.success
                    });
                }).catch((error) => {
                    err = { error: messages.changed_password_failed, statusCode: 417 }
                    return next(err)
                });
            }
        });
    }

};

/**
 ** Logout from device and remove the token from database 
 */
const logout = (req, res, next) => {
    var query = {
        _id: req._id
    };
    var projection = {
        aJwtTokens: true
    };
    usersModel.findOne(query, projection, (error, user) => {
        var token = req.header('Authorization');
        if (error) {
            err = { error: error }
            return next(err)
        }
        if (!user){
            err = { error: messages.user_not_found, statusCode: 404 }
            return next(err)
        } 
        var tokenDoc = _.find(user.aJwtTokens, ['sDeviceAuth', token]);
        if (!_.isEmpty(tokenDoc)) {
            tokenDoc.remove();
        }

        user.save().then((success) => {
            return res.status(200).jsonp({
                "message": messages.logout_success
            });
        }).catch((error) => {
            err = { error: messages.logout_failed, statusCode: 417 }
            return next(err)
        });
    });
};

/**
 ** GET my profile details 
 */
const myProfile = (req, res, next) =>{
    let sUserId = req._id;

    usersModel.findOne(
        {
            _id: ObjectId(sUserId)
        },
        {
            _id:1,
            sFirstName: 1,
            sLastName: 1,
            sEmail: 1,
            sCountryCode: 1,
            sMobile: 1,
            eStatus: 1,
            sProfileImage: 1,
            sIdentityProof: 1,
            dCreatedDate: 1,
            sMobileVerified:1,
            sEmailVerified:1,
            sProfilePicture:1,
            sPayPalEmail:1

        },
        (err, profile) =>{
            if(err) return next(err);
            if(_.isEmpty(profile)) {
                err = { error: messages.user_not_found, statusCode: 404 }
                return next(err)
            }
            return res.status(200).jsonp({
                "message": messages.success,
                'data' : profile
            });
        })
};

/**
 ** Resend Email for verify account 
 */
const resendEmailVerification =(req, res, next) =>{
    let sUserId = req._id;

    usersModel.findOne({_id: ObjectId(sUserId)},{_id:1, sEmail:1, sFirstName:1,sEmailVerified:1}, (err, user) =>{
        if(err) return next(err);
        if(_.isEmpty(user)) {
            err = { error: messages.user_not_found, statusCode: 404 }
            return next(err)
        }
        if(_.isEmpty(user.sEmail)) {
            err = { error: messages.err_req_email, statusCode: 404 }
            return next(err)
        }
        
        if(user.sEmailVerified ==1) {
            err = { error: messages.email_already_verified, statusCode: 409}
            return next(err)
        }

        //send email for user verification 
        var newUser = new usersModel();
        var sActivationToken = md5(randomString({
            length: 6,
            letters: true
        }));
        usersModel.update({
            _id: user._id
        }, {
            $set: {
                sActivationToken: sActivationToken
            }
        }).then((success) => {
            var template = fs.readFileSync(constants.emailTemplatePath + 'account_activation.html', {
                encoding: 'utf-8'
            });
            var ACTIVELINK = SITE_URL + 'verifyemail/' + sActivationToken

            var emailBody = ejs.render(template, {
                sUsername:user.sFirstName,
                SITE_IMAGE: constants.siteImage,
                SITE_NAME: constants.siteName,
                ACTIVELINK: ACTIVELINK
            });
            var mailOption = {
                to: user.sEmail, // list of receivers
                subject: "Account Activation", // Subject line
                html: emailBody
            }
            newUser.sendEmail(mailOption).then(function(success) {
                return res.status(200).jsonp({
                    "message":  messages.msg_send_email_verification+' '+user.sEmail  //messages.success,
                });
            }).catch(function(err) {
                err = { error: messages.something_wentwrong, statusCode: 405 }
                return next(err)
            });
        });

    });
    
}

/**
 ** Change the password of login user
 */
const profilePassswordChange = (req, res, next) => {
    let body = _.pick(req.body, ['sNewPassword', 'sConfirmPassword','sCurrentPassword']);

    if(_.isEmpty(body.sCurrentPassword)) {
        err = {error: messages.err_req_password, statusCode: 400};
        return next(err);
    }

    if(_.isEmpty(body.sNewPassword)) {
        err = {error: messages.err_req_newpassword, statusCode: 400};
        return next(err);
    }

    if(_.isEmpty(body.sConfirmPassword)) {
        err = {error: messages.err_repassword, statusCode: 400};
        return next(err);
    }

    if(body.sNewPassword != body.sConfirmPassword) {
        err = { error:messages.password_not_matched, statusCode: 400 }
        return next(err)
    }


    usersModel.findOne({'_id':ObjectId(req._id)}, {_id:1, sUserName:1,sPassword:1 }, (err,user)=> {
        if(err) return next(err);
        if(_.isEmpty(user)) {
            err = { error: messages.user_not_found, statusCode: 404 }
            return next(err)
        }

        if (bcrypt.compareSync(body.sCurrentPassword, user.sPassword)) {
            //change password
            var salt            = bcrypt.genSaltSync(10);
            var hash            = bcrypt.hashSync(body.sNewPassword,salt);
            usersModel.update(
                {'_id': ObjectId(user._id)},
                {
                    $set :{
                        sPassword : hash
                    }
                }
            ).then((success)=>{
                return res.status(200).jsonp({
                    'message' : messages.success
                })
            }).catch((err)=>{
                err = { error: messages.fail, statusCode: 417 }
                return next(err)
            });
        } else {
            err = { error: messages.cur_pass_unmatch, statusCode: 404 }
            return next(err)
        }
    });
};


/**
 ** Add Paypal Emal Address 
 */
const addPaypalEmail = (req, res, next) =>{
    let body = _.pick(req.body, ['sEmail']);
    if(_.isEmpty(body.sEmail)) {
        err = { error: messages.err_req_email, statusCode:400}
        return next(err);
    }
    usersModel.update(
        {_id:ObjectId(req._id)},
        {
            $set:{
                sPayPalEmail : body.sEmail
            }
        }
    ).then((success)=>{
        return res.status(200).jsonp({
            'message':messages.success
        })
    });
}

/**
 ** Edit the profile picture
 ** If profile picture already exist then remove previous images  
 */
const editProfilePicture = (req, res, next) => {
    uploadProfile(req, res, function(err) {
        var query = {
            _id: ObjectId(req._id)
        };
        usersModel.findOne(query, {
            _id: 1,
            sProfilePicture: 1,
        }, (err, user) => {
            if (err) return next(err);
            if (_.isEmpty(user)) {
                err = { error: messages.user_not_found, statusCode: 404 }
                return next(err)
            }

            var remove_prev_picture     =  false;
            var prev_profile_picture    = user.sProfilePicture;
            var imagefilename           = user.sProfilePicture;
            if(!_.isUndefined(prev_profile_picture) && !_.isEmpty(prev_profile_picture)){    
                remove_prev_picture =  true;
            }
           
            var sProfilePicture = '';
            var sThumbProfilePicture = '';
            if (!_.isEmpty(req.files)) {
                var myFileObject = req.files;
                //AMazon S3 Bucket Path :'https://snipture.s3.amazonaws.com/user_avtar/b9b9cc890a0dcabfb0bf3859c25a20d6.jpeg'
                var sProfilePictureObj = myFileObject.sProfilePicture;
                if (!_.isUndefined(sProfilePictureObj)) {
                    //Get Image Name based on uploaded path
                    if(mediaUploadPath == 's3') {
                        imgname = sProfilePictureObj[0].key;
                    } else {
                        imgname = sProfilePictureObj[0].filename;
                    } 
                    sProfilePicture = 'user_avtar/'+imgname;
                }
            }
            //remove profile picture if exist 
            if(remove_prev_picture) {
                imgpath = constants.uploadPath + '/' +imagefilename;
                //imgthumbpath = constants.uploadPath + '/' +imagethumbfilename; 
                if(mediaUploadPath == 's3') {
                    //Delete object from s3 bucket 
                    var params = {
                        Bucket: constants.awsS3Bucket, 
                        Delete: {
                        Objects: [ 
                            {
                            Key: imagefilename
                            }
                          
                        ],
                        },
                    };
                    s3.deleteObjects(params, function(err, data) {
                        if (err)  return next(err)//console.log(err, err.stack);
                        //else  // console.log(data); 
                    });
                } else { //remove from local
                    if(!_.isUndefined(imagefilename)) {
                        const stats = fs.statSync(imgpath);
                        if (stats) { 
                        fs.unlinkSync(imgpath);
                        }
                    }
                }    
            }
            usersModel.update(query, {
                $set: { 
                    sProfilePicture : sProfilePicture, 
                    dUpdatedDate : utility.nowDate()  
                }
            }).then((success) => {
                return myProfile(req,res,next);
            }).catch((error) => {
                err = { error: messages.fail, statusCode: 417 }
                return next(err)
            }); 

        });
    });
};

module.exports = {
    registerService,
    varifyEmail,
    loginService,
    forgetPassword,
    resetPassword,
    logout,
    myProfile,
    resendEmailVerification,
    profilePassswordChange,
    addPaypalEmail,
    editProfilePicture,
    checkemailService,
    checkmobileService,
    varifyPassword,
    changePassword
}