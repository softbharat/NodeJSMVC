
const _ = require('lodash');
const usersModel = require('../../models/users_models');
const messages = require('../../messages/messages');
const jwt = require('jsonwebtoken');
var ObjectId = require('mongodb').ObjectID;

const isAuth = (req, res, next) => {
    var token = req.header('Authorization');
    jwt.verify(token, constants.jwtPassphere, function(err, decoded) {
    usersModel.findByToken(token).then((user) => {
        
        if (!user) return res.status(401).jsonp({ "error": messages.user_session_expired });
        if (user.eStatus === 'd') return res.status(423).jsonp({ "error": messages.user_disabled });
        if (user.eStatus === 'n') return res.status(408).jsonp({ "error": messages.not_varified });
        req._id = user._id;
      // console.log(req._id);
        return next(null, user);
    }).catch((error) => {
        return res.status(401).jsonp({ "error": messages.user_session_expired }); //unauthorized
    });
});
}


module.exports = {
    isAuth
};