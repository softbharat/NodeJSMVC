/**
 * @todo : ALL the configuration of project like portnumber and body parsing and database connection
 * @constants contains all the credentials need to be secure
 * @publicPath stores the Adminside logic written in Angularjs
 */
const path = require('path');
const bodyParser = require('body-parser');
const expressDevice = require('express-device');
const mongoose = require('mongoose');
mongoose.set('debug', true);
const debug = require('debug')('http')
const publicPath = path.join(__dirname, './public');
const constants = require('./costants');

const port = 8080;

var config = function(app) {
    debug('listening debug');
    //app.use(bodyParser.json());
    //app.use(bodyParser.urlencoded({ extended: true }));
    app.use(bodyParser.urlencoded({limit: '50mb',extended: true}));
    app.use(bodyParser.json({limit: '50mb'}));
    app.use(expressDevice.capture());
    app.use(require('express').static(publicPath));
    mongoose.connection.openUri(constants.dbUrl, function(err, db) {
       if(err){
         console.log("Database....." + err);  
       }
    });
    mongoose.Promise = global.Promise;
    app.listen(port, () => {
        console.log("Run....." + port);
    });
};

module.exports = config;

